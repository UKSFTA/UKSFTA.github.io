import { test, expect } from '@playwright/test';

test.describe('ORBAT Canvas', () => {
    test.beforeEach(async ({ page }) => {
        await page.addInitScript(() => {
            window.localStorage.setItem('uksf_auth', 'authorized');
            window.localStorage.setItem('uksf_hq_auth', 'true');
        });
        await page.goto('/registry/orbat');
    });

    test('should load the canvas and admin bar', async ({ page }) => {
        await expect(page.locator('#orbat-canvas')).toBeAttached();
        await expect(page.locator('#hq-admin-bar')).toHaveAttribute('data-visible', 'true');
    });
});
