import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import cors from 'cors';

const app = express();
const PORT = process.env.REGISTRY_SERVICE_PORT || 3002;

app.use(cors());
app.use(express.json());

const CONTENT_DIR = path.resolve(process.cwd(), 'exampleSite/content/campaigns');

app.post('/api/file', (req, res) => {
    const { slug, title, date, content, metadata } = req.body;
    if (!slug || !content) return res.status(400).json({ error: "Missing data." });
    const filePath = path.join(CONTENT_DIR, `${slug}.md`);
    const mdContent = `---
title: "${title}"
date: "${date}"
layout: "campaign"
type: "fragment"
---

${content}`;
    try {
        if (!fs.existsSync(CONTENT_DIR)) fs.mkdirSync(CONTENT_DIR, { recursive: true });
        fs.writeFileSync(filePath, mdContent);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.listen(PORT, '0.0.0.0', () => { console.log(`[REGISTRY_SERVICE] Active on ${PORT}`); });