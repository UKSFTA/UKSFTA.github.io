import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const contentDir = path.join(__dirname, '../content');
const dataFile = path.join(__dirname, '../data/system_stats.json');

// Helper to recursively get files
function getFiles(dir) {
    const dirents = fs.readdirSync(dir, { withFileTypes: true });
    const files = dirents.map((dirent) => {
        const res = path.resolve(dir, dirent.name);
        return dirent.isDirectory() ? getFiles(res) : res;
    });
    return Array.prototype.concat(...files);
}

try {
    const files = getFiles(contentDir);
    const fileCount = files.length;
    
    // Calculate total size in bytes
    const totalSize = files.reduce((acc, file) => {
        const stats = fs.statSync(file);
        return acc + stats.size;
    }, 0);

    // Get last git commit hash (short)
    let commitHash = 'UNKNOWN';
    try {
        commitHash = execSync('git rev-parse --short HEAD').toString().trim();
    } catch (e) {
        console.warn("Git not available or not a repo.");
    }

    // Convert size to readable format
    const sizeKB = (totalSize / 1024).toFixed(2);
    const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
    
    const stats = {
        record_count: fileCount,
        db_size_bytes: totalSize,
        db_size_fmt: sizeMB > 1 ? `${sizeMB} MB` : `${sizeKB} KB`,
        last_sync: new Date().toISOString(),
        node_id: `UK_LON_HQ_${commitHash.toUpperCase()}`,
        threat_level: "SUBSTANTIAL", // Could be dynamic based on campaigns?
        active_ops: 0 // Placeholder, handled by Hugo counting campaigns
    };

    fs.writeFileSync(dataFile, JSON.stringify(stats, null, 2));
    console.log('System stats generated:', stats);

} catch (error) {
    console.error('Error generating stats:', error);
}