import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:1313',
    trace: 'on-first-retry',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  ],
  webServer: [
    { command: 'npm run start', url: 'http://localhost:1313', reuseExistingServer: true },
    { command: 'npm run service:registry', port: 3002, reuseExistingServer: true },
    { command: 'npm run service:rcon', port: 3001, reuseExistingServer: true }
  ],
});
